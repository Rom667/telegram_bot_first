# основная клавиартура
from aiogram.types import (ReplyKeyboardMarkup, KeyboardButton,
InlineKeyboardMarkup, InlineKeyboardButton)

# основная клавиатура при вызове /start
main = ReplyKeyboardMarkup(keyboard=[
    [KeyboardButton(text='От 1 до 100')],
    [KeyboardButton(text='Корзина'), KeyboardButton(text='Контакты')]
],
# доп настрйоки клавиатуры
                        resize_keyboard=True,
                        input_field_placeholder='Выберете пункт меню')

# клавиатура моего гип при вызове /git
git_button = InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text='Мой Git hub', url='https://github.com/Rom667')]])