# импорты библиотек
from aiogram import F, Router
from aiogram.filters import CommandStart, Command
from aiogram.types import Message

# импорты из других файлов бота
import app.keyboards as kb

# имя роутера
router = Router()

# команды:
# /start
@router.message(CommandStart())
async def cmd_start(message: Message):
    await message.answer(f'Првиет, {message.from_user.first_name}!',
                         reply_markup=kb.main)

# ссылка на мой гит хаб
@router.message(Command('git'))
async def git_my(message: Message):
    await message.answer(f'Мой гит-хаб: ', reply_markup=kb.git_button)

# help
@router.message(Command('help'))
async def get_help(message: Message):
    await message.answer('это команда /help')

# как дела?
@router.message(F.text == 'как дела?')
async def how_are_you(message: Message):
    await message.answer('Хорошо')

# если пользователь отправит фото, то ему придет ID
@router.message(F.photo)
async def get_photo(message: Message):
    await message.answer(f'ID photo: {message.photo[-1].file_id}')

# обои, отправка фоткой
@router.message(Command('wallpapers'))
async def wallpapers(message: Message):
    await message.answer_photo('AgACAgIAAxkBAAMNaLGwmzvBpAOD2I2yAXQfAaGeJckAAuP4MRvj_pBJrZYTnYJcmq4BAAMCAAN5AAM2BA')

# клавиатура от 1 до 100
@router.message(F.text == 'От 1 до 100')
async def zeto_to_hudrit(message: Message):
    numbers = "\n".join(str(i) for i in range(1, 101))
    await message.answer(numbers)